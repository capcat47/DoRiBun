package com.doo.controller;

import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.doo.frontcontroller.Command;
import com.doo.model.BadgeDTO;





public class BadgeService implements Command {
		
		@Override
		public String excute(HttpServletRequest request, HttpServletResponse response) {
			
		
			return null;
		}
	
	    
	    
	    
	}
	
